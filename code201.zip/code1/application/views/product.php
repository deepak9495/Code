<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><?php echo anchor('Ctrl_home/index','Home');?></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_employee/index','employee');?></li>
	<li><?php echo anchor('Ctrl_cat/index','category');?></li>
li><?php echo anchor('Ctrl_product/index','Products');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
<!--Contact Data-->
<div class="col-md-9">
<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal">
  Entry
</button>
<!--Contact Data-->
<!--Table Data-->
<table class="table table-striped">
    <thead>
      <tr>
        <th>Product ID</th>
        <th>Product Name</th>
	<th>Product Description</th>
	<th>Product price</th>
	<th>Stock</th>
	<th>Category ID</th>
	<th>Image</th>

	<th>Operation</th>
      </tr>
    </thead>
    <tbody>
	<?php
  foreach($product as $item)
  {
  	?>
      <tr>
        <td><?php echo $item['pid'];?></td>
        <td><?php echo $item['pname'];?></td>
	 <td><?php echo $item['desc'];?></td>
	 <td><?php echo $item['prize'];?></td>
	 <td><?php echo $item['stock'];?></td>
	 <td><?php echo $item['cat'];?></td>
	 <td><?php echo $item['image'];?></td>
        
	<td><?php echo anchor('Ctrl_product/edit_product/'.$item['pid'],'Edit');?>/<?php echo anchor('Ctrl_product/delete/'.$item['pid'],'Delete');?></td>
      </tr>
   <?php
   }
   ?>  
    </tbody>
  </table>
  
<!--Table Data-->
</div>

</div>
</div>
<!--Modal Data-->
<?php echo form_open('Ctrl_product/product_entry'); ?> 
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Product Entry</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      
      <div class="modal-body">
      
	<div class="col-md-8 offset-2">
		<div class="form-group">
		<label>Product ID</label>
		<input type='text' name='pid' class='form-control' placeholder='productid'>
		</div>
		<div class="form-group">
		<label>Product name</label>
		<input type='text' name='pname' class='form-control' placeholder='productname'>
		</div>
<div class="form-group">
		<label>Product Description</label>
		<input type='text' name='desc' class='form-control' placeholder='productdescription'>
		</div>
<div class="form-group">
		<label>Price</label>
		<input type='text' name='prize' class='form-control' placeholder='productprice'>
		</div>
<div class="form-group">
		<label>Stock</label>
		<input type='text' name='stock' class='form-control' placeholder='stock'>
		</div>
<div class="form-group">
		<label>Category ID</label>
		<input type='text' name='cat' class='form-control' placeholder='categoryid'>
		</div>
<div class="form-group">
		<label>Product Image</label>
		<input type='text' name='image' class='form-control' placeholder='productimage'>
		</div>

		
	</div>       



      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
	<button type="submit" class="btn btn-primary" >Enter</button>
       
      </div>

    </div>
  </div>
</div>
<?php echo form_close(); ?>
<!--Modal Data-->
