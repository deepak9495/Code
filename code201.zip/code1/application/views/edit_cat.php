<?php
echo form_open('Ctrl_cat/update_cat');
?>
<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><?php echo anchor('Ctrl_home/index','Home');?></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_cat/index','Category');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
<!--Contact Data-->

<div class="col-md-9">
<div class="row">

<div class="col-md-6 offset-3">
	<h5 class="text-center">Update Category</h5>
	
	<!--form-->
	<div class="form-group">
	<label>ID</label>
	<input type='text' name='id' value="<?php echo $cat['id'];?>" class='form-control'>
	</div>
	<!--form-->
	<!--form-->
	<div class="form-group">
	<label>Name</label>
	<input type='text' name='name' value="<?php echo $cat['name'];?>" class='form-control'>
	</div>
	<!--form-->
	<!--form-->
	
	<input type='hidden' name='txtHid' value="<?php echo $cat['id'];?>"> 
	<input type='submit' value='Update' class='btn btn-primary float-right'>
</div>

</div>
</div>
</div>
</div>
<?php
echo form_close();
?>
