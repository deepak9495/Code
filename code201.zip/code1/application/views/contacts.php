<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><?php echo anchor('Ctrl_home/index','Home');?></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_employee/index','employee');?></li>
	<li><?php echo anchor('Ctrl_cat/index','category');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
<!--Contact Data-->
<div class="col-md-9">
<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal">
  Entry
</button>
<!--Contact Data-->
<!--Table Data-->
<table class="table table-striped">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Mobile</th>
        <th>Email</th>	
	<th>Operation</th>
      </tr>
    </thead>
    <tbody>
	<?php
  foreach($contacts as $item)
  {
  	?>
      <tr>
        <td><?php echo $item['name'];?></td>
        <td><?php echo $item['mobile'];?></td>
        <td><?php echo $item['email'];?></td>
	<td><?php echo anchor('Ctrl_contacts/edit_contact/'.$item['mobile'],'Edit');?>/<?php echo anchor('Ctrl_contacts/delete/'.$item['mobile'],'Delete');?></td>
      </tr>
   <?php
   }
   ?>  
    </tbody>
  </table>
  
<!--Table Data-->
</div>

</div>
</div>
<!--Modal Data-->
<?php echo form_open('Ctrl_contacts/contact_entry'); ?> 
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Contact Entry</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      
      <div class="modal-body">
      
	<div class="col-md-8 offset-2">
		<div class="form-group">
		<label>FirstName</label>
		<input type='text' name='txtName' class='form-control' placeholder='Firstname'>
		</div>
		<div class="form-group">
		<label>Email</label>
		<input type='text' name='txtEmail' class='form-control' placeholder='Email'>
		</div>
		<div class="form-group">
		<label>Mobile</label>
		<input type='text' name='txtMobile' class='form-control' placeholder='Mobile'>
		</div>
	</div>       



      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
	<button type="submit" class="btn btn-primary" >Enter</button>
       
      </div>

    </div>
  </div>
</div>
<?php echo form_close(); ?>
<!--Modal Data-->
