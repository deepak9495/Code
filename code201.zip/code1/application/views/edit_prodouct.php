<?php
echo form_open('Ctrl_product/update_product');
?>
<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><?php echo anchor('Ctrl_home/index','Home');?></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_cat/index','Category');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
<!--Contact Data-->

<div class="col-md-9">
<div class="row">

<div class="col-md-6 offset-3">
	<h5 class="text-center">Update product</h5>
	
	<!--form-->
	<div class="form-group">
	<label>ID</label>
	<input type='text' name='pid' value="<?php echo $product['pid'];?>" class='form-control'>
	</div>
	<!--form-->
	<!--form-->
	<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductDescription</label>
	<input type='text' name='desc' value="<?php echo $product['desc'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
<div class="form-group">
	<label>ProductName</label>
	<input type='text' name='pname' value="<?php echo $product['pname'];?>" class='form-control'>
	</div>
	<!--form-->
	<!--form-->
	
	<input type='hidden' name='txtHid' value="<?php echo $product['pid'];?>"> 
	<input type='submit' value='Update' class='btn btn-primary float-right'>
</div>

</div>
</div>
</div>
</div>
<?php
echo form_close();
?>
