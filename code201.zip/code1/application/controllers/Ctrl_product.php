<?php
class Ctrl_product extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Mdl_product');
	}
	public function index()
	{
		$data['product']=$this->Mdl_product->get_all_product();
		$this->load->view('header');
		$this->load->view('product',$data);
		$this->load->view('footer');
	}
	public function product_entry()
	{
	$pid=$this->input->post('pid');
	$pname=$this->input->post('pname');
	$desc=$this->input->post('desc');
	$prize=$this->input->post('prize');
	$stock=$this->input->post('stock');
	$cat=$this->input->post('cat');
	$image=$this->input->post('image');
	$ar1=array('pid'=>$pid,'pname'=>$pname,'desc'=>$desc,'prize'=>$prize,'stock'=>$stock,'cat'=>$cat,'image'=>$image);
	$this->Mdl_product->product_entry($ar1);
	redirect('Ctrl_product/index');
	}
	public function delete($pid=-1)
	{
		if($pid==-1)
		{
			redirect('Ctrl_product/index');
		}
		else
		{
			$this->db->where('pid',$pid);
			if($this->db->delete('product_entry'))
			{
				redirect('Ctrl_product/index');
			
			}
			else
			{
				redirect('Ctrl_product/index');
				
			}
			
		}
		
	}
		public function edit_product($pid)
	{
		$data['product']=$this->Mdl_product->get_spec_product($pid);
		$this->load->view('header');
		$this->load->view('edit_product',$data);
		$this->load->view('footer');	
	}
	public function update_product()
	{
		$pid=$this->input->post('pid');
		$pname=$this->input->post('pname');
		
		$ar1=array('pid'=>$pid,'pname'=>$pname);
		$pid=$this->input->post('txtHid');
		if($this->Mdl_product->update_product($ar1,$pid))
		{
			redirect('Ctrl_product/index');
		}
		else
		{
			redirect('Ctrl_product/index');
		}	
	}
		
}





?>
