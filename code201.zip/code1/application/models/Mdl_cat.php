<?php
class Mdl_cat extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function cat_entry($pksu)
	{
		
		$this->db->insert('cat_entry',$pksu);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function get_all_cat()
	{
	$res=$this->db->get('cat_entry');
	return $res->result_array();
	
	}
	public function get_spec_cat($id)
	{
		$res=$this->db->get_where('cat_entry',array('id'=>$id));
		if($row=$res->row_array())
		{
			return $row;
		}
		else
		{
			return false;
		}
		
	}
	public function update_cat($data,$id)
	{
		$this->db->where('id',$id);
		if($this->db->update('cat_entry',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>
