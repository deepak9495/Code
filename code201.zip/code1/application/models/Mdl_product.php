<?php
class Mdl_product extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function product_entry($pksu)
	{
		
		$this->db->insert('product_entry',$pksu);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function get_all_product()
	{
	$res=$this->db->get('product_entry');
	return $res->result_array();
	
	}
	public function get_spec_product($pid)
	{
		$res=$this->db->get_where('product_entry',array('pid'=>$pid));
		if($row=$res->row_array())
		{
			return $row;
		}
		else
		{
			return false;
		}
		
	}
	public function update_product($data,$pid)
	{
		$this->db->where('pid',$pid);
		if($this->db->update('product_entry',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>
