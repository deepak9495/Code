<?php
class Ctrl_users extends CI_Controller
{

  public function __construct()
  {
	parent::__construct();
        $this->load->helper('url');
	$this->load->helper('form');
	$this->load->library('session');
	$this->load->model('Mdl_users');
	
  }
  public function index()
  {
	if($this->input->post())
	{
		$email=$this->input->post('txtEmail');
		$pass=$this->input->post('txtPass');
		$data=array('email'=>$email,'password'=>$pass);
		if($this->Mdl_users->lg_chk($data))
		{
			redirect('Ctrl_home/index');	
			
		}
		else
		{
			redirect('Ctrl_users/index');
		}
		
	}
	$this->load->view('header');
	$this->load->view('login');
	$this->load->view('footer');
	
	

  }
  public function registration()
  {
  	if($this->input->post())
	{
		$name=$this->input->post('txtFname');
		$email=$this->input->post('txtEmail');
		$mobile=$this->input->post('txtMobile');
		$pass=$this->input->post('txtPass');
		$cpass=$this->input->post('txtConfirm');
		$data=array('fname'=>$name,'email'=>$email,'mobile'=>$mobile,'password'=>$pass);
		if($this->Mdl_users->user_register($data))
		{
			echo "Registration Success";
		}
		else
		{
			echo "Registration Failed";
		}
			
		
		
		
	}
  	$this->load->view('header');
	$this->load->view('register');
	$this->load->view('footer');
	
  }	
  public function logout()
  {
  	$this->session->set_userdata('userDetails','');
  	session_unset();
  	redirect('Ctrl_users/index');
  }
  
	
	

}

?>
