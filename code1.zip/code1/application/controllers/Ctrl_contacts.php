<?php
class Ctrl_contacts extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
	}
	public function index()
	{
		$this->load->view('header');
		$this->load->view('contacts');
		$this->load->view('footer');
	}
}
?>
