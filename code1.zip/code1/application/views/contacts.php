<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><?php echo anchor('Ctrl_home/index','Home');?></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
<!--Contact Data-->
<div class="col-md-9">
<button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#myModal">
  Entry
</button>
<!--Contact Data-->
<!--Table Data-->
<table class="table table-striped">
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Mobile</th>
        <th>Email</th>	
	<th>Operation</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>John</td>
        <td>Doe</td>
        <td>john@example.com</td>
	<td><a href='#'>Edit</a>/<a href='#'>Delete</a></td>
      </tr>
      <tr>
        <td>Mary</td>
        <td>Moe</td>
        <td>mary@example.com</td>
	<td><a href='#'>Edit</a>/<a href='#'>Delete</a></td>
      </tr>
      <tr>
        <td>July</td>
        <td>Dooley</td>
        <td>july@example.com</td>
	<td><a href='#'>Edit</a>/<a href='#'>Delete</a></td>
      </tr>
    </tbody>
  </table>
<!--Table Data-->
</div>

</div>
</div>
<!--Modal Data-->
<!-- The Modal -->
<div class="modal" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Contact Entry</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
	<div class="col-md-8 offset-2">
		<div class="form-group">
		<label>FirstName</label>
		<input type='text' name='txtName' class='form-control' placeholder='Firstname'>
		</div>
		<div class="form-group">
		<label>Email</label>
		<input type='text' name='txtEmail' class='form-control' placeholder='Email'>
		</div>
		<div class="form-group">
		<label>Mobile</label>
		<input type='text' name='txtMobile' class='form-control' placeholder='Mobile'>
		</div>
	</div>       



      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
	<button type="button" class="btn btn-primary" >Enter</button>
       
      </div>

    </div>
  </div>
</div>
<!--Modal Data-->
