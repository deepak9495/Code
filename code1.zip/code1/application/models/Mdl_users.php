<?php
class Mdl_users extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function user_register($data)
	{
		
		$this->db->insert('users',$data);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function lg_chk($data)
	{
		$res=$this->db->get_where('users',$data);
		if($row=$res->row_array())
		{
			$this->session->set_userdata('userDetails',$row);
			return true;
		}
		else
		{
			return false;
		}	
	}
}
?>
