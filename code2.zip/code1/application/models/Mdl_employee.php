<?php
class Mdl_employee extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	public function employee_entry($pksu)
	{
		
		$this->db->insert('employee_entry',$pksu);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function get_all_employee()
	{
	$res=$this->db->get('employee_entry');
	return $res->result_array();
	
	}
	public function get_spec_employee($mob)
	{
		$res=$this->db->get_where('employee_entry',array('mobile'=>$mob));
		if($row=$res->row_array())
		{
			return $row;
		}
		else
		{
			return false;
		}
		
	}
	public function update_employee($data,$id)
	{
		$this->db->where('mobile',$id);
		if($this->db->update('employee_entry',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>
