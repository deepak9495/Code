<?php
class Mdl_contacts extends CI_Model
{
	public function __construct()																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																																								
	{
		parent::__construct();
		$this->load->database();
	}
	public function contact_entry($pksu)
	{
		
		$this->db->insert('contact_entry',$pksu);
		if($this->db->affected_rows()>0)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	public function get_all_contacts()
	{
	$res=$this->db->get('contact_entry');
	return $res->result_array();
	
	}
	public function get_spec_contacts($mob)
	{
		$res=$this->db->get_where('contact_entry',array('mobile'=>$mob));
		if($row=$res->row_array())
		{
			return $row;
		}
		else
		{
			return false;
		}
		
	}
	public function update_contact($data,$id)
	{
		$this->db->where('mobile',$id);
		if($this->db->update('contact_entry',$data))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
?>
