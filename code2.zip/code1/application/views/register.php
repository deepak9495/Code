<div class="container">
<div class="row">
<div class="col-md-4 offset-4" style="margin-top:50px;">
<?php
echo form_open('Ctrl_users/registration');
?>
<h4 class="text-center">Register Here</h4>
<!--Form-->
<div class="form-group">
	<label>FirstName</label>
	<input type='text' name='txtFname' placeholder='FirstName' class='form-control' required>
</div>
<div class="form-group">
	<label>Email</label>
	<input type='email' name='txtEmail' placeholder='Email' class='form-control' required>
</div>
<div class="form-group">
	<label>Mobile</label>
	<input type='text' name='txtMobile' placeholder='Mobile' class='form-control' required>
</div>
<div class="form-group">
	<label>Password</label>
	<input type='password' name='txtPass' placeholder='Password' class='form-control' required>
</div>
<div class="form-group">
	<label>Confirm</label>
	<input type='password' name='txtConfirm' placeholder='Confirm' class='form-control' required>
</div>
<?php
echo anchor('Ctrl_users/index','Home');
?>
<input type='submit' value='Register' class='btn btn-primary float-right'>
<?php
echo form_close();
?>
<!--Form-->
</div>
</div>
</div>
