<div class="container" style="border-bottom:1px solid #333333;">
<div class="row">
<div class="col-md-12">
<h4 class="text-center">User home</h4>
</div>
</div>
</div>
<div class="container" style="min-height:500px;">
<div class="row">
<!--UserMenu-->
<div class="col-md-3">

<ul>
	<li><a href='#'>Home</a></li>
	<li><?php echo anchor('Ctrl_contacts/index','Contacts');?></li>
	<li><?php echo anchor('Ctrl_employee/index','Employee');?></li>
	<li><?php echo anchor('Ctrl_cat/index','category');?></li>
	<li><?php echo anchor('Ctrl_users/logout','Logout');?></li>

</ul>

</div>
<!--User Menu-->
</div>
</div>
