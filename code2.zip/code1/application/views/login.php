<div class="container">
<div class="row">

<div class="col-md-4 offset-4" style="margin-top:50px;">
<?php
echo form_open('Ctrl_users/index');
?>
<h4 class="text-center">Login Here</h4>
<!--Form-->
<div class="form-group">
	<label>Email</label>
	<input type='email' name='txtEmail' placeholder='Email' class='form-control' required>
</div>
<div class="form-group">
	<label>Password</label>
	<input type='password' name='txtPass' placeholder='Password' class='form-control' required>
</div>
<?php
echo anchor('Ctrl_users/registration','Register');
?>
<input type='submit' value='Login' class='btn btn-primary float-right'>
<?php
echo form_close();
?>
<!--Form-->
</div>

</div>
</div>
