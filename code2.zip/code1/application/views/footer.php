<div class="container">
<div class="row">
<div class="col-md-12">
<p class="text-center">Designed & Developed by AKHIL</p>
</div>
</div>
</div>
<script type='text/javascript' src="<?php echo base_url();?>/external/bst/js/jq1.js">
</script>
<script type='text/javascript' src="<?php echo base_url();?>/external/bst/js/bootstrap.min.js">
</script>

</body>
</html>
