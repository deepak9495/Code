<?php
class Ctrl_cat extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Mdl_cat');
	}
	public function index()
	{
		$data['cat']=$this->Mdl_cat->get_all_cat();
		$this->load->view('header');
		$this->load->view('cat',$data);
		$this->load->view('footer');
	}
	public function cat_entry()
	{
	$id=$this->input->post('id');
	$name=$this->input->post('name');
	
	$ar1=array('id'=>$id,'name'=>$name);
	$this->Mdl_cat->cat_entry($ar1);
	redirect('Ctrl_cat/index');
	}
	
	public function delete($id=-1)
	{
		if($id==-1)
		{
			redirect('Ctrl_cat/index');
		}
		else
		{
			$this->db->where('id',$id);
			if($this->db->delete('cat_entry'))
			{
				redirect('Ctrl_cat/index');
			
			}
			else
			{
				redirect('Ctrl_cat/index');
				
			}
			
		}
		
	}
	
		public function edit_cat($id)
	{
		$data['cat']=$this->Mdl_cat->get_spec_cat($id);
		$this->load->view('header');
		$this->load->view('edit_cat',$data);
		$this->load->view('footer');	
	}
	public function update_cat()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('name');
		$ar1=array('id'=>$id,'name'=>$name,);
		$id=$this->input->post('txtHid');
		if($this->Mdl_cat->update_cat($ar1,$id))
		{
			redirect('Ctrl_cat/index');
		}
		else
		{
			redirect('Ctrl_cat/index');
		}	
	}
		
}





?>
