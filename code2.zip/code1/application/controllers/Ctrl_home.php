<?php
class Ctrl_home extends CI_Controller
{

  public function __construct()
  {
	parent::__construct();
        $this->load->helper('url');
	$this->load->helper('form');
	$this->load->library('session');
		
  }
  public function index()
  {
  	if($this->session->userdata('userDetails'))
  	{
  	$this->load->view('header');
  	$this->load->view('user_home');
  	$this->load->view('footer');
  	}
  	else
  	{
  		redirect('Ctrl_users/index');
  	}
  		
  }
}
?>
