<?php
class Ctrl_contacts extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Mdl_contacts');
	}
	public function index()
	{
		$data['contacts']=$this->Mdl_contacts->get_all_contacts();
		$this->load->view('header');
		$this->load->view('contacts',$data);
		$this->load->view('footer');
	}
	public function contact_entry()
	{
	$name=$this->input->post('txtName');
	$email=$this->input->post('txtEmail');
	$mobile=$this->input->post('txtMobile');
	$ar1=array('name'=>$name,'email'=>$email,'mobile'=>$mobile);
	$this->Mdl_contacts->contact_entry($ar1);
	redirect('Ctrl_contacts/index');
	}
	public function delete($id=-1)
	{
		if($id==-1)
		{
			redirect('Ctrl_contacts/index');
		}
		else
		{
			$this->db->where('mobile',$id);
			if($this->db->delete('contact_entry'))
			{
				redirect('Ctrl_contacts/index');
			
			}
			else
			{
				redirect('Ctrl_contacts/index');
				
			}
			
		}
		
	}
	public function edit_contact($mobile)
	{
		$data['contacts']=$this->Mdl_contacts->get_spec_contacts($mobile);
		$this->load->view('header');
		$this->load->view('edit_contact',$data);
		$this->load->view('footer');	
	}
	public function update_contact()
	{
		$name=$this->input->post('txtName');
		$email=$this->input->post('txtEmail');
		$mobile=$this->input->post('txtMobile');
		$ar1=array('name'=>$name,'email'=>$email,'mobile'=>$mobile);
		$id=$this->input->post('txtHid');
		if($this->Mdl_contacts->update_contact($ar1,$id))
		{
			redirect('Ctrl_contacts/index');
		}
		else
		{
			redirect('Ctrl_contacts/index');
		}	
	}
		
}
?>
