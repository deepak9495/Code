<?php
class Ctrl_employee extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->model('Mdl_employee');
	}
	public function index()
	{
		$data['employee']=$this->Mdl_employee->get_all_employee();
		$this->load->view('header');
		$this->load->view('employee',$data);
		$this->load->view('footer');
	}
	public function employee_entry()
	{
	$name=$this->input->post('txtName');
	$email=$this->input->post('txtEmail');
	$mobile=$this->input->post('txtMobile');
	$ar1=array('name'=>$name,'email'=>$email,'mobile'=>$mobile);
	$this->Mdl_employee->employee_entry($ar1);
	redirect('Ctrl_employee/index');
	}
	public function delete($id=-1)
	{
		if($id==-1)
		{
			redirect('Ctrl_employee/index');
		}
		else
		{
			$this->db->where('mobile',$id);
			if($this->db->delete('employee_entry'))
			{
				redirect('Ctrl_employee/index');
			
			}
			else
			{
				redirect('Ctrl_employee/index');
				
			}
			
		}
		
	}
		public function edit_employee($mobile)
	{
		$data['employee']=$this->Mdl_employee->get_spec_employee($mobile);
		$this->load->view('header');
		$this->load->view('edit_employee',$data);
		$this->load->view('footer');	
	}
	public function update_employee()
	{
		$name=$this->input->post('txtName');
		$email=$this->input->post('txtEmail');
		$mobile=$this->input->post('txtMobile');
		$ar1=array('name'=>$name,'email'=>$email,'mobile'=>$mobile);
		$id=$this->input->post('txtHid');
		if($this->Mdl_employee->update_employee($ar1,$id))
		{
			redirect('Ctrl_employee/index');
		}
		else
		{
			redirect('Ctrl_employee/index');
		}	
	}
		
}





?>
